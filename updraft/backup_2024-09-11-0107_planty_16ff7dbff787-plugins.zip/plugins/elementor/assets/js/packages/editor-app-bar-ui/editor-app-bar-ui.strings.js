__( 'More', 'elementor' );
__( 'Elementor Logo', 'elementor' );
__( 'Integrations', 'elementor' );